import paramiko

hostname = "192.168.127.134"
username = "dewinet"
password = "Dew241144@"
port = 22

try:
    # Establish the transport connection
    with paramiko.Transport((hostname, port)) as transport:
        transport.connect(username=username, password=password)
        print(f"[+] Connected to {hostname} via SSH")

        # SFTP client for file operations
        with paramiko.SFTPClient.from_transport(transport) as sftp:
            # Download file
            print("[+] Starting file download")
            remote_file_path = "/home/dewinet/Desktop/dew.txt"
            local_file_path = "C:/Users/cnrrm/Downloads/FTP___LOAD/dewww.txt"
            sftp.get(remote_file_path, local_file_path)
            print("[+] File download complete")

            # Upload file
            print("[+] Starting file upload")
            upload_local_path = "C:/Users/cnrrm/Downloads/FTP___LOAD/dewww.txt" #ตำแหน่งของ  PC (client)เรา 
            upload_remote_path = "/home/dewinet/Desktop/u.txt" #ตำแหน่งของ ไฟล์ บน vmvare(server) เรา
            sftp.put(upload_local_path, upload_remote_path)
            print("[+] File upload complete")

        print("[+] Disconnected from server")

except Exception as err:
    print(f"[!] Error: {str(err)}")