import paramiko

hostname = "192.168.127.134"
port = 22
user = "dewinet"
passwd = "Dew241144@"

try:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, port=port, username=user, password=passwd)

    shell = client.invoke_shell()  # สร้าง interactive shell session
    shell.recv(1000)  # รอรับข้อความต้อนรับของ shell (เช่น Banner message)

    while True:
        try:
            cmd = input("$> ")
            if cmd.lower() == "exit":
                break

            shell.send("cd Desktop\n")     #ใช้ คำสั้ง cdm ผ่าน code
            shell.send("mkdir DEW_TEST\n") 

            shell.send(cmd + "\n")  # ส่งคำสั่งไปยัง shell
            response = shell.recv(5000).decode()  # รอรับผลลัพธ์จาก shell
            print(response)
        except KeyboardInterrupt:
            break

    client.close()
except Exception as err:
    print(str(err))

#คำสั่งติดตั่ง ssh บน vmware 
#sudo apt install openssh-server
#sudo service ssh status